#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef VECTOR_H
#define VECTOR_H

typedef struct vector_dinamico {
  void** elementos;
  size_t cantidad_elementos;
} vector_t;

vector_t* vector_crear();

void* vector_agregar(vector_t* vector, void* elemento);

void vector_eliminar(vector_t* vector);

void vector_print(vector_t* vector);

#endif  // VECTOR_H
