#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#define ELEMENTOS_POR_RESERVACION 16

typedef struct vector_dinamico {
  void** elementos;
  size_t cantidad_elementos;
  size_t tamanio;
} vector_t;

/*
 * Reserva memoria para un vector dinamico y lo inicializa.
 *
 * Devuelve el puntero o NULL en caso de error
 */
vector_t* vector_crear() {
  return calloc(1, sizeof(vector_t));
}

/*
 * Recibe un vector y un puntero que agrega al vector
 *
 * Devuelve el puntero al vector con el elemento agregado 
 * o NULL en caso de que el vector no exista o haya un error
 * reservando memoria.
 * 
 * si ya tiene espacio reservado para este elemento, lo agrega, sino reserva mas espacio
 */
vector_t* vector_agregar(vector_t* vector, void* elemento) {
  if (!vector) return NULL;
  if (vector->cantidad_elementos == vector->tamanio) {
    void** vector_aux = realloc(vector->elementos, (vector->cantidad_elementos + ELEMENTOS_POR_RESERVACION) * sizeof(void*));
    if (!vector_aux) return NULL;
    vector->elementos = vector_aux;
    vector->tamanio += ELEMENTOS_POR_RESERVACION;
  }

  vector->elementos[vector->cantidad_elementos] = elemento;
  vector->cantidad_elementos++;
  return vector;
}

/*
 * Recibe un vector al que le libera de memoria
 */
void vector_eliminar(vector_t* vector) {
  if (!vector) return;
  free(vector->elementos);
  free(vector);
}
