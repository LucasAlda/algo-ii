
#include "hospital.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "split.h"

#define POSICION_ENTRENADOR_ID 0
#define POSICION_ENTRENADOR_NOMBRE 1
#define POSICION_PRIMER_POKEMON 2
#define SEPARADOR_ARCHIVO ';'
#define LECTURA_DEFAULT_LINEA 100

typedef struct _entrenador_pkm_t entrenador_t;

struct _hospital_pkm_t {
  size_t cantidad_pokemon;
  size_t cantidad_entrenador;
  pokemon_t* vector_pokemones;
  entrenador_t* vector_entrenadores;
};

struct _entrenador_pkm_t {
  size_t id;
  char* nombre;
};

struct _pkm_t {
  char* nombre;
  size_t nivel;
  size_t entrenador_id;
};

/**
 * Reserva memoria para un hospital y la inicializa.
 *
 * Devuelve NULL en caso de no poder.
 */
hospital_t* hospital_crear() {
  return calloc(1, sizeof(hospital_t));
}

/**
 * Recibe un archivo del que lee una linea completa y colocandola dinamicamente en la memoria
 * 
 * Devuelve NULL si el archivo no existe, no lee nada o hay algun error reservando memoria,
 * caso contrario devuelve el puntero al string
 */
char* leer_linea_completa(FILE* archivo) {
  if (!archivo) return NULL;
  size_t leido = 0;
  size_t tamanio = LECTURA_DEFAULT_LINEA;
  char* linea_heap = malloc(tamanio);

  if (!linea_heap) return NULL;

  while (fgets(linea_heap + leido, (int)(tamanio - leido), archivo)) {
    size_t nueva_lectura = strlen(linea_heap + leido);
    if (nueva_lectura > 0 && *(linea_heap + leido + nueva_lectura - 1) == '\n') {
      *(linea_heap + leido + nueva_lectura - 1) = '\0';
      return linea_heap;
    } else {
      char* linea_heap_aux = realloc(linea_heap, tamanio * 2);
      if (!linea_heap_aux) {
        free(linea_heap);
        return NULL;
      }
      linea_heap = linea_heap_aux;
      tamanio *= 2;
    }
    leido += nueva_lectura;
  }

  if (leido == 0) {
    free(linea_heap);
    return NULL;
  }

  archivo += leido;

  return linea_heap;
}

/**
 * La funcion recibe el nombre, nivel e id del entrenador validos y devuelve un pokemon inicializado 
 */
pokemon_t crear_pokemon(char* nombre, size_t nivel, size_t entrenador_id) {
  pokemon_t nuevo_pokemon;
  nuevo_pokemon.nombre = nombre;
  nuevo_pokemon.entrenador_id = entrenador_id;
  nuevo_pokemon.nivel = nivel;
  return nuevo_pokemon;
}

/**
 * recibe un vector de pokemones con su cantidad, el vector de strings con los pokemones ingresados, el id del entrenador que hizo 
 * el ingreso y la cantidad de nuevos pokemones (todos validados previamente)
 * 
 * agranda la reserva de memoria del vector y agrega los nuevos pokemones
 * si la reserva de momemoria falla devuelve NULL, caso contrario devuelve el puntero del vector agrandado
 */
pokemon_t* agregar_pokemones(pokemon_t* vector_pokemones, size_t cantidad_pokemon, size_t entrenador_id, char** ingreso_entrenador, size_t cant_nuevos_pokemones) {
  pokemon_t* vector_pokemones_aux = realloc(vector_pokemones, (cantidad_pokemon + cant_nuevos_pokemones) * sizeof(pokemon_t));
  if (!vector_pokemones_aux) return NULL;
  vector_pokemones = vector_pokemones_aux;

  // el primer elemento de ingreso_entrenador con informacion de pokemones es el 3ero porque los primeros dos son del entrenador
  size_t ingreso_entrenador_posicion = POSICION_PRIMER_POKEMON;

  for (size_t i = 0; i < cant_nuevos_pokemones; i++) {
    pokemon_t nuevo_pokemon = crear_pokemon(ingreso_entrenador[ingreso_entrenador_posicion], (size_t)atoi(ingreso_entrenador[ingreso_entrenador_posicion + 1]), entrenador_id);
    vector_pokemones[cantidad_pokemon + i] = nuevo_pokemon;
    ingreso_entrenador_posicion += 2;
  }

  return vector_pokemones;
}

/**
 * recibe un vector de entrenadores valido con su cantidad, y el nombre e id del nuevo entrenador validos, ademas de la configuracion 
 * de si agregar repetidos o verificar si ya esta creado
 * 
 * si no se desea repitir, la funcion revisa que el entrenador no exista y en caso de existir devuelve el vector igual
 * si no existe o se habilita la repeticion, agranda la reserva del vector, agrega el nuevo entrenador y devuelve el vector nuevo
 * en caso de error reservando memoria devuelve NULL
 */
entrenador_t* agregar_entrenador(entrenador_t* vector_entrenadores, size_t* cantidad_entrenador, char* entrenador_nombre, size_t entrenador_id, bool no_repetir) {
  // si se configura como no agregar entrenadores repetidos se revisa que no este, esto se va a usar desactivado para que pase las pruebas
  if (no_repetir) {
    for (size_t i = 0; i < *cantidad_entrenador; i++) {
      if (vector_entrenadores[i].id == entrenador_id) return vector_entrenadores;
    }
  }

  entrenador_t* vector_entrenadores_aux = realloc(vector_entrenadores, ((*cantidad_entrenador) + 1) * sizeof(entrenador_t));
  if (!vector_entrenadores_aux) return NULL;

  entrenador_t entrenador_nuevo;
  entrenador_nuevo.nombre = entrenador_nombre;
  entrenador_nuevo.id = entrenador_id;

  vector_entrenadores_aux[*cantidad_entrenador] = entrenador_nuevo;
  (*cantidad_entrenador)++;

  return vector_entrenadores_aux;
}

/**
 * Recibe un hospital valido, un vector de strings del ingreso de pokemones de un entrenador validado con su cantidad de elementos
 * 
 * La funcion se ocupa de interpretar el formato del string y almacenar los datos del entrenador y sus pokemones en el hospital 
 * devolviendo el hospital actualizado o NULL en caso de error reservando memoria
 */
hospital_t* hospital_agregar_entrenador_y_pokemones(hospital_t* hospital, char** ingreso_entrenador, size_t cantidad_elementos_leida) {
  char* entrenador_nombre = ingreso_entrenador[POSICION_ENTRENADOR_NOMBRE];
  size_t entrenador_id = (size_t)atoi(ingreso_entrenador[POSICION_ENTRENADOR_ID]);

  entrenador_t* vector_entrenadores_aux = agregar_entrenador(hospital->vector_entrenadores, &(hospital->cantidad_entrenador), entrenador_nombre, entrenador_id, false);
  if (!vector_entrenadores_aux) {
    return NULL;
  }

  // se le resta dos por el nombre y id del entrenador, el /2 es porque hay dos datos por entrenador
  size_t cant_nuevos_pokemones = (cantidad_elementos_leida - 2) / 2;
  pokemon_t* vector_pokemones_aux = agregar_pokemones(hospital->vector_pokemones, hospital->cantidad_pokemon, entrenador_id, ingreso_entrenador, cant_nuevos_pokemones);
  if (!vector_pokemones_aux) {
    return NULL;
  }

  hospital->vector_entrenadores = vector_entrenadores_aux;
  hospital->vector_pokemones = vector_pokemones_aux;
  hospital->cantidad_pokemon += cant_nuevos_pokemones;

  return hospital;
}

/**
 * la funcion recibe el vector de strings valido con los datos del ingreso de pokemones por un entrenador leido del archivo al cual
 * va a liberar de memoria, tambien recibe un bool que marca si libera los nombres de la memoria o no (si no hay errores previos
 * se prevee que los punteros de strings se reutilizen en el hospital y no hay que liberarlos en esta instancia)
 */
void eliminar_informacion_ingreso_entrenador(char** ingreso_entrenador, bool liberar_strings) {
  free(ingreso_entrenador[POSICION_ENTRENADOR_ID]);
  if (liberar_strings) free(ingreso_entrenador[POSICION_ENTRENADOR_NOMBRE]);

  size_t i = POSICION_PRIMER_POKEMON;
  while (ingreso_entrenador[i]) {
    if (liberar_strings) free(ingreso_entrenador[i]);
    free(ingreso_entrenador[i + 1]);
    i += 2;
  }
  free(ingreso_entrenador);
}

/**
 * Lee un archivo con entrenadores que hacen tratar a sus pokemon en el hospital y los agrega al mismo.
 *
 * Ver en el enunciado el formato del archivo. Si algo falla, el hospital no es modificado.
 *
 * En caso de error devuelve false. Caso contrario, true.
 */
bool hospital_leer_archivo(hospital_t* hospital, const char* nombre_archivo) {
  FILE* archivo = fopen(nombre_archivo, "r");
  if (!archivo) return false;
  char* linea = leer_linea_completa(archivo);

  while (linea) {
    size_t cantidad_elementos_leida = 0;
    char** ingreso_entrenador = split(linea, SEPARADOR_ARCHIVO);

    free(linea);
    if (!ingreso_entrenador) {
      fclose(archivo);
      return false;
    }

    while (ingreso_entrenador[cantidad_elementos_leida]) cantidad_elementos_leida++;

    // si no hay al menos dos elementos (nombre e id del entrenador) o la cantidad de elementos es
    // par (id y nombre del entrenador o nombre y nivel de pokemones), el archivo esta mal y se devuelve false liberando todo antes
    if (cantidad_elementos_leida < 2 || cantidad_elementos_leida % 2 != 0) {
      eliminar_informacion_ingreso_entrenador(ingreso_entrenador, true);
      fclose(archivo);
      return false;
    }

    hospital_t* hospital_aux = hospital_agregar_entrenador_y_pokemones(hospital, ingreso_entrenador, cantidad_elementos_leida);
    if (!hospital_aux) {
      eliminar_informacion_ingreso_entrenador(ingreso_entrenador, true);
      fclose(archivo);
      return false;
    }

    eliminar_informacion_ingreso_entrenador(ingreso_entrenador, false);
    linea = leer_linea_completa(archivo);
  }

  fclose(archivo);

  return true;
}

/**
 * Devuelve la cantidad de pokemon que son atendidos actualmente en el hospital.
 */
size_t hospital_cantidad_pokemon(hospital_t* hospital) {
  if (!hospital) return 0;
  return hospital->cantidad_pokemon;
}

/**
 * Devuelve la cantidad de entrenadores que actualmente hacen atender a sus
 * pokemon en el hospital.
 */
size_t hospital_cantidad_entrenadores(hospital_t* hospital) {
  if (!hospital) return 0;
  return hospital->cantidad_entrenador;
}

/**
 * Recibe un vector de pokemones y su  tope
 * 
 * La funcion se encarga de ordenar el vector alfabeticamente
 *  
 */

void ordenar_pokemones_alfabeticamente(pokemon_t* vector_pokemones, size_t cantidad_pokemon) {
  int i = 0;
  bool cambio = true;
  while (i < (int)cantidad_pokemon - 1 && cambio) {
    cambio = false;
    for (int j = 0; j < (int)cantidad_pokemon - i - 1; j++) {
      if (strcmp(vector_pokemones[j].nombre, vector_pokemones[j + 1].nombre) > 0) {
        pokemon_t aux = vector_pokemones[j];
        vector_pokemones[j] = vector_pokemones[j + 1];
        vector_pokemones[j + 1] = aux;
        cambio = true;
      }
    }
  }
}

/**
 * Aplica una función a cada uno de los pokemon almacenados en el hospital. La
 * función debe aplicarse a cada pokemon en orden alfabético.
 *
 * La función a aplicar recibe el pokemon y devuelve true o false. Si la función
 * devuelve true, se debe seguir aplicando la función a los próximos pokemon si
 * quedan. Si la función devuelve false, no se debe continuar.
 *
 * Devuelve la cantidad de pokemon a los que se les aplicó la función (hayan devuelto true o false).
 */
size_t hospital_a_cada_pokemon(hospital_t* hospital, bool (*funcion)(pokemon_t* p)) {
  if (!hospital || !funcion) return 0;

  ordenar_pokemones_alfabeticamente(hospital->vector_pokemones, hospital->cantidad_pokemon);

  for (size_t i = 0; i < hospital->cantidad_pokemon; i++) {
    if (!funcion(&(hospital->vector_pokemones[i]))) return i + 1;
  }

  return hospital->cantidad_pokemon;
}

/**
 *  Libera el hospital y toda la memoria utilizada por el mismo.
 */
void hospital_destruir(hospital_t* hospital) {
  if (!hospital) return;
  for (size_t i = 0; i < hospital->cantidad_pokemon; i++) {
    if (hospital->vector_pokemones[i].nombre) free(hospital->vector_pokemones[i].nombre);
  }
  for (size_t i = 0; i < hospital->cantidad_entrenador; i++) {
    if (hospital->vector_entrenadores[i].nombre) free(hospital->vector_entrenadores[i].nombre);
  }

  free(hospital->vector_pokemones);
  free(hospital->vector_entrenadores);
  free(hospital);
}

/**
 * Devuelve el nivel de un pokemon o 0 si el pokemon es NULL.
 */
size_t pokemon_nivel(pokemon_t* pokemon) {
  if (!pokemon) return 0;
  return pokemon->nivel;
}

/**
 * Devuelve el nombre de un pokemon o NULL si el pokemon es NULL.
 */
const char* pokemon_nombre(pokemon_t* pokemon) {
  if (!pokemon) return NULL;
  return pokemon->nombre;
}
